<template>
  <q-page class="flex flex-center">
    <img
      alt="mityma logo"
      src="~assets/seeding.svg"
      style="width: 200px; height: 200px;"
    >
  </q-page>
</template>

<script>
import { defineComponent } from 'vue';

export default defineComponent({
  name: 'IndexPage',
});
</script>

from .command import Command
from sqlalchemy import Table, MetaData
from sqlalchemy.ext.declarative import declarative_base


class SelectCommand(Command):
    def __init__(self, **kwargs) -> None:
        pass

    def execute(self) -> None:
        print('select')


class UpsertCommand(Command):
    def __init__(self, session, model) -> None:
        self.session = session
        self.model = model

    def execute(self) -> None:
        self.session.add(self.model)


class DeleteCommand(Command):
    def __init__(self, session, model) -> None:
        self.session = session
        self.model = model

    def execute(self) -> None:
        meta = MetaData()
        meta.reflect(bind=self.session.get_bind())
        table = Table(self.model.__tablename__, meta)
        self.session.query(table).filter(table.c.id == self.model.id).delete()


class CommitCommand(Command):
    def __init__(self, session, statements: dict) -> None:
        self.session = session
        self.statements = statements


    def execute(self) -> None:
        transactions = ['upsert', 'delete']
        for transaction in transactions:
            for statement in self.statements[transaction]:
                if transaction == 'upsert':
                    command = UpsertCommand(self.session, statement)
                else:
                    command = DeleteCommand(self.session, statement)
                command.execute()

        self.session.commit()


class RollbackCommand(Command):
    def __init__(self, session) -> None:
        self.session = session

    def execute(self) -> None:
        self.session.rollback()

